const SETTINGS = {
    serverUrl: "http://localhost:61016/",
    clientUrl: "http://localhost:8099/",
    successInterval: 1000,
    errorInterval: 5000
}

export default SETTINGS;